using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Clash;
using System.Reflection;
using Autodesk.Navisworks.Api.Interop;
using Autodesk.Navisworks.Api.ComApi;
using System.Windows.Input;
using System.Windows.Forms.Integration;
using System.Threading;
using System.Windows.Threading;
using System.IO;

namespace ClashManager.ManagerCollision.Views
{
	public partial class ManagerCollisionView : Window
		{
		private Document _doc;
		private DocumentClash _documentClash;
		// Чекбоксы выбора: для строк коллизий и для тестов
		private readonly System.Collections.Generic.HashSet<Guid> _checkedRowIds = new System.Collections.Generic.HashSet<Guid>();
		private readonly System.Collections.Generic.HashSet<Guid> _checkedTestIds = new System.Collections.Generic.HashSet<Guid>();

		public ManagerCollisionView()
		{
			InitializeComponent();
			// Сброс лога при старте окна
			try { File.WriteAllText(GetLogPath(), ""); } catch { }
			// Включаем клавиатурную интероп-совместимость для модельного окна в Win32-хосте (Navisworks)
			try { ElementHost.EnableModelessKeyboardInterop(this); } catch { }
			// Обеспечим корректную активацию окна и ввод с клавиатуры
			try
			{
				// Привязываем Owner к главному окну процесса Navisworks для корректной активации
				var hwnd = System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle;
				if (hwnd != IntPtr.Zero)
				{
					new System.Windows.Interop.WindowInteropHelper(this).Owner = hwnd;
				}
			}
			catch { }
			this.WindowStyle = WindowStyle.SingleBorderWindow; // Обычный стиль окна
			this.ShowInTaskbar = false; // Не обязательно, но удобно
			this.Topmost = true; // Позволяет окну получать фокус поверх Navisworks
			this.Loaded += (s, e) =>
			{
				try
				{
					this.Activate();
					this.Focus();
					// Установим фокус в первое поле ввода, чтобы сразу работала клавиатура
					if (FindBox != null)
						System.Windows.Input.Keyboard.Focus(FindBox);
				}
				catch { }
			};
			_doc = Autodesk.Navisworks.Api.Application.ActiveDocument;
			_documentClash = _doc.GetClash();
			LoadTests();
		}

		private void LoadTests()
		{
			var tests = _documentClash?.TestsData?.Tests?.OfType<ClashTest>()?.ToList() ?? Enumerable.Empty<ClashTest>().ToList();
			// Оборачиваем в объекты с IsSelected для чекбоксов
			var testRows = tests.Select(t => new { Test = t, DisplayName = t.DisplayName, IsSelected = false, Guid = t.Guid }).ToList();
			TestsList.ItemsSource = testRows;
		}

		private sealed class ResultRow
		{
			public ClashResult Result { get; set; }
			public string GroupName { get; set; }
			public ClashResultGroup ParentGroup { get; set; }
		}

		private void TestsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			var selectedTest = (TestsList.SelectedItem != null) ? (TestsList.SelectedItem.GetType().GetProperty("Test")?.GetValue(TestsList.SelectedItem) as ClashTest) : null;
			if (selectedTest == null)
			{
				CollisionsList.ItemsSource = null;
				return;
			}

			// Показываем по одной строке на группу, плюс отдельные (негрупповые) результаты теста
			var groupRows = EnumerateAllGroupsWithLevel(selectedTest)
				.Select(x => new
				{
					Name = x.Group.DisplayName ?? string.Empty,
					Status = x.Group.Status.ToString(),
					AssignedTo = (x.Group.AssignedTo ?? string.Empty).ToString(),
					Guid = x.Group.Guid,
					IsGroup = true,
					IsSelected = false
				});

			var ungroupedResultRows = selectedTest.Children
				.OfType<ClashResult>()
				.Select(r => new
				{
					Name = r.DisplayName ?? string.Empty,
					Status = r.Status.ToString(),
					AssignedTo = (r.AssignedTo ?? string.Empty).ToString(),
					Guid = r.Guid,
					IsGroup = false,
					IsSelected = false
				});

			var rows = groupRows.Concat(ungroupedResultRows).ToList();
			CollisionsList.ItemsSource = rows;
		}

		private System.Collections.Generic.IEnumerable<(ClashResultGroup Group, int Level)> EnumerateAllGroupsWithLevel(ClashTest test)
		{
			foreach (var g in test.Children.OfType<ClashResultGroup>())
			{
				yield return (g, 0);
				foreach (var child in EnumerateAllGroupsWithLevel(g, 1))
					yield return child;
			}
		}

		private System.Collections.Generic.IEnumerable<(ClashResultGroup Group, int Level)> EnumerateAllGroupsWithLevel(ClashResultGroup group, int level)
		{
			foreach (var g in group.Children.OfType<ClashResultGroup>())
			{
				yield return (g, level);
				foreach (var child in EnumerateAllGroupsWithLevel(g, level + 1))
					yield return child;
			}
		}


		// Поиск и навигация
		private void SearchButton_Click(object sender, RoutedEventArgs e) => ApplySearch();
		private void ResetButton_Click(object sender, RoutedEventArgs e)
		{
			SetSearchText(string.Empty);
			TestsList_SelectionChanged(null, null);
		}
		private void SearchBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == System.Windows.Input.Key.Enter) ApplySearch();
		}

		private void ApplySearch()
		{
			var selectedTest = TestsList.SelectedItem as ClashTest;
			if (selectedTest == null) { MessageBox.Show("Выберите тест."); return; }
			string query = (GetSearchText() ?? string.Empty).Trim();
			if (string.IsNullOrEmpty(query)) { TestsList_SelectionChanged(null, null); return; }

			Guid guidQuery;
			bool isGuid = Guid.TryParse(query, out guidQuery);

			// 0) Попробуем найти по всем тестам и сразу открыть
			if (TryGlobalSearchAndOpen(query, isGuid, guidQuery)) return;

			var rows = CollisionsList.Items.Cast<object>();
			var filtered = rows.Where(item =>
			{
				var t = item.GetType();
				string name = (t.GetProperty("Name")?.GetValue(item) as string) ?? string.Empty;
				Guid id = t.GetProperty("Guid") != null ? (Guid)t.GetProperty("Guid").GetValue(item) : Guid.Empty;
				if (isGuid) return id == guidQuery;
				return name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 || id.ToString().IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;
			}).ToList();

			CollisionsList.ItemsSource = filtered;

			// Авто-открытие первой совпавшей коллизии/группы
			var first = filtered.FirstOrDefault();
			if (first != null)
			{
				CollisionsList.SelectedItem = first;
				CollisionsList_MouseDoubleClick(null, null);
			}
		}

		private bool TryGlobalSearchAndOpen(string query, bool isGuid, Guid guidQuery)
		{
			try
			{
				var tests = _documentClash?.TestsData?.Tests?.OfType<ClashTest>()?.ToList();
				if (tests == null || tests.Count == 0) return false;

				foreach (var test in tests)
				{
					// Поиск по результатам
					foreach (var r in GetAllResultsFromTest(test))
					{
						bool match = isGuid ? r.Guid == guidQuery : ((r.DisplayName ?? string.Empty).IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 || r.Guid.ToString().IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0);
						if (match)
						{
							OpenFound(test, r.Guid, false);
							return true;
						}
					}

					// Поиск по группам
					foreach (var tpl in EnumerateAllGroupsWithLevel(test))
					{
						var g = tpl.Group;
						bool match = isGuid ? g.Guid == guidQuery : ((g.DisplayName ?? string.Empty).IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 || g.Guid.ToString().IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0);
						if (match)
						{
							OpenFound(test, g.Guid, true);
							return true;
						}
					}
				}
			}
			catch { }
			return false;
		}

		private void OpenFound(ClashTest test, Guid id, bool isGroup)
		{
			try
			{
				// Выбираем тест
				TestsList.SelectedItem = test;
				TestsList_SelectionChanged(null, null);

				// Выбираем строку
				object rowToSelect = null;
				foreach (var item in CollisionsList.Items)
				{
					var t = item.GetType();
					Guid rowId = t.GetProperty("Guid") != null ? (Guid)t.GetProperty("Guid").GetValue(item) : Guid.Empty;
					if (rowId == id) { rowToSelect = item; break; }
				}
				if (rowToSelect != null)
				{
					CollisionsList.SelectedItem = rowToSelect;
					CollisionsList.ScrollIntoView(rowToSelect);
				}

				// Открываем 3D и Clash Detective
				if (isGroup)
				{
					var group = FindGroupByGuid(test, id);
					if (group != null)
					{
						var items = new ModelItemCollection();
						foreach (var r in GetAllResultsFromGroup(group))
						{
							if (r.CompositeItem1 != null) items.Add(r.CompositeItem1);
							if (r.CompositeItem2 != null) items.Add(r.CompositeItem2);
						}
						ActivateClashDetective(test, group);
						FocusOnItems(items);
					}
				}
				else
				{
					var clash = FindResultByGuid(test, id);
					if (clash != null)
					{
						var items = new ModelItemCollection();
						if (clash.CompositeItem1 != null) items.Add(clash.CompositeItem1);
						if (clash.CompositeItem2 != null) items.Add(clash.CompositeItem2);
						ActivateClashDetective(test, clash);
						FocusOnItems(items);
					}
				}
			}
			catch { }
		}

		private string GetSearchText()
		{
			try
			{
				var tb = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "SearchBox") as System.Windows.Controls.TextBox;
				return tb?.Text ?? string.Empty;
			}
			catch { return string.Empty; }
		}

		private bool GetCheckBoxState(string name)
		{
			try
			{
				var cb = System.Windows.LogicalTreeHelper.FindLogicalNode(this, name) as System.Windows.Controls.CheckBox;
				return cb?.IsChecked ?? false;
			}
			catch { return false; }
		}

		private System.Collections.Generic.List<object> GetCheckedCollisionRows()
		{
			var result = new System.Collections.Generic.List<object>();
			foreach (var item in CollisionsList.Items.Cast<object>())
			{
				var type = item.GetType();
				Guid id = type.GetProperty("Guid") != null ? (Guid)type.GetProperty("Guid").GetValue(item) : Guid.Empty;
				if (id != Guid.Empty && _checkedRowIds.Contains(id)) result.Add(item);
			}
			return result;
		}

		private bool IsTestMarkedForRename(ClashTest test)
		{
			return _checkedTestIds.Contains(test.Guid);
		}

		// Обработчики кликов по чекбоксам в XAML
		private void CollisionCheckBox_Click(object sender, RoutedEventArgs e)
		{
			var cb = sender as System.Windows.Controls.CheckBox;
			if (cb == null) return;
			// Найдём Guid из DataContext строки
			if (cb.DataContext != null)
			{
				var t = cb.DataContext.GetType();
				Guid id = t.GetProperty("Guid") != null ? (Guid)t.GetProperty("Guid").GetValue(cb.DataContext) : Guid.Empty;
				if (id != Guid.Empty)
				{
					if (cb.IsChecked == true) _checkedRowIds.Add(id); else _checkedRowIds.Remove(id);
				}
			}
		}

		private void TestCheckBox_Click(object sender, RoutedEventArgs e)
		{
			var cb = sender as System.Windows.Controls.CheckBox;
			if (cb == null) return;
			// В шаблоне у нас Tag привязан к Guid
			var tag = cb.Tag;
			if (tag is Guid g)
			{
				if (cb.IsChecked == true) _checkedTestIds.Add(g); else _checkedTestIds.Remove(g);
			}
		}

		private void SetSearchText(string text)
		{
			try
			{
				var tb = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "SearchBox") as System.Windows.Controls.TextBox;
				if (tb != null) tb.Text = text ?? string.Empty;
			}
			catch { }
		}

		private void CollisionsList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			var selected = CollisionsList.SelectedItem;
			if (selected == null) return;

			var t = selected.GetType();
			bool isGroup = t.GetProperty("IsGroup") != null && (bool)t.GetProperty("IsGroup").GetValue(selected);
			Guid id = t.GetProperty("Guid") != null ? (Guid)t.GetProperty("Guid").GetValue(selected) : Guid.Empty;

			// Получаем выбранный тест из TestsList.SelectedItem
			ClashTest selectedTest = null;
			var testObj = TestsList.SelectedItem;
			if (testObj != null)
			{
				var testType = testObj.GetType();
				var testProp = testType.GetProperty("Test");
				if (testProp != null)
					selectedTest = testProp.GetValue(testObj) as ClashTest;
			}
			if (selectedTest == null || id == Guid.Empty) return;

			ModelItemCollection items = new ModelItemCollection();
			SavedItem issue = null;

			if (isGroup)
			{
				var group = FindGroupByGuid(selectedTest, id);
				if (group != null)
				{
					foreach (var r in GetAllResultsFromGroup(group))
					{
						if (r.CompositeItem1 != null) items.Add(r.CompositeItem1);
						if (r.CompositeItem2 != null) items.Add(r.CompositeItem2);
					}
					issue = group;
				}
			}
			else
			{
				var clash = FindResultByGuid(selectedTest, id);
				if (clash != null)
				{
					if (clash.CompositeItem1 != null) items.Add(clash.CompositeItem1);
					if (clash.CompositeItem2 != null) items.Add(clash.CompositeItem2);
					issue = clash;
				}
			}

			// 1. Активируем в Clash Detective
			if (issue != null)
				ActivateClashDetective(selectedTest, issue);

			// 2. Выделяем и зуммируем в 3D
			if (items.Count > 0)
				FocusOnItems(items);
		}

		private bool SelectClashInDetective(ClashTest test, SavedItem issue)
		{
			try
			{
				var comState = ComApiBridge.State; // InwOpState
				if (comState == null) return false;
				// Достаём Clash через отражение: либо свойство "Clash", либо ищем свойство с типом, содержащим "Clash"
				object comClash = comState.GetType().GetProperty("Clash", BindingFlags.Public | BindingFlags.Instance)?.GetValue(comState);
				if (comClash == null)
				{
					foreach (var p in comState.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
					{
						var pt = p.PropertyType?.Name ?? string.Empty;
						if (pt.IndexOf("Clash", StringComparison.OrdinalIgnoreCase) >= 0)
						{
							try { comClash = p.GetValue(comState); } catch { comClash = null; }
							if (comClash != null) break;
						}
					}
					if (comClash == null) return false;
				}

				// Находим тест по GUID
				object comTest = null;
				var testsCollection = comClash.GetType().GetProperty("TestsData")?.GetValue(comClash)
									?.GetType().GetProperty("Tests")?.GetValue(comClash.GetType().GetProperty("TestsData")?.GetValue(comClash));
				foreach (var ct in EnumerateComCollection(testsCollection))
				{
					if ((Guid)ct.GetType().GetProperty("Guid")?.GetValue(ct) == test.Guid)
					{
						comTest = ct;
						break;
					}
				}
				if (comTest == null) return false;

				// Устанавливаем текущий тест
				comClash.GetType().GetProperty("CurrentTest")?.SetValue(comClash, comTest);

				// Находим issue по GUID (результат или группа)
				object comIssue = FindComIssueByGuidRecursive(comTest, GetIssueGuidForActivation(issue));
				if (comIssue != null)
				{
					comClash.GetType().GetProperty("CurrentResult")?.SetValue(comClash, comIssue);
					return true;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Ошибка выбора коллизии в Clash Detective: " + ex.Message);
			}
			return false;
		}


		private void ActivateClashDetective(ClashTest test, SavedItem issue)
		{
			try
			{
				Log($"Activate start: test={test?.Guid}, issue={issue?.Guid}, type={issue?.GetType().Name}");
				if (test == null) return;
				var opState = _doc?.State as LcOpState;
				if (opState == null) return;
				var currentIssueCtl = LcClCurrentIssue.GetInstance(opState);
				if (currentIssueCtl == null) return;

				// Активируем панель Clash Detective (если возможно), чтобы выбор не терялся
				TryActivateClashPanelUi();
				PumpDispatcherOnce();
				Log("Clash panel activated");

				// Открываем тест через managed API
				TryInvokeMethod(currentIssueCtl, new[] { "SetCurrentTest", "SelectTest" }, new object[] { test });
				Log($"Managed set test: {test.Guid}");
				// Managed: если выбрана группа — выставляем группу; если выбран результат — сначала группа родителя, затем результат
				bool managedIssueSelected = false;
				if (issue is ClashResultGroup selGroup)
				{
					TryInvokeMethod(currentIssueCtl, new[] { "SetCurrentGroup", "SelectGroup" }, new object[] { selGroup });
					// NW2020: подождём и проверим, что реально выбралась нужная группа
					managedIssueSelected = VerifyManagedSelection(currentIssueCtl, selGroup.Guid, isGroup: true);
				}
				else if (issue is ClashResult selResult)
				{
					var parentGroup = selResult.Parent as ClashResultGroup;
					if (parentGroup != null)
						TryInvokeMethod(currentIssueCtl, new[] { "SetCurrentGroup", "SelectGroup" }, new object[] { parentGroup });
					TryInvokeMethod(currentIssueCtl, new[] { "SetCurrentResult", "SelectResult", "SetCurrentIssue", "SelectIssue" }, new object[] { selResult });
					managedIssueSelected = VerifyManagedSelection(currentIssueCtl, selResult.Guid, isGroup: false);
				}

				// Открываем тест и результат через COM API
				try
				{
					var comState = ComApiBridge.State;
					if (comState == null) { Log("COM state is null"); }
					if (comState != null)
					{
						var clashProp = comState.GetType().GetProperty("Clash", BindingFlags.Public | BindingFlags.Instance);
						var comClash = clashProp?.GetValue(comState);
						if (comClash == null)
						{
							// NW2020 fallback: ищем любой публичный инстанс-свойство, у которого тип или имя содержит "Clash"
							foreach (var p in comState.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
							{
								try
								{
									var pt = p.PropertyType?.Name ?? string.Empty;
									if (pt.IndexOf("Clash", StringComparison.OrdinalIgnoreCase) >= 0 ||
										p.Name.IndexOf("Clash", StringComparison.OrdinalIgnoreCase) >= 0)
									{
										var val = p.GetValue(comState);
										if (val != null) { comClash = val; Log($"COM Clash fallback via property '{p.Name}'"); break; }
									}
								}
								catch { }
							}
						}
						if (comClash == null) { Log("COM Clash is null"); }
						if (comClash != null)
						{
							Log("COM Clash acquired");
							var testsDataProp = comClash.GetType().GetProperty("TestsData", BindingFlags.Public | BindingFlags.Instance);
							var testsData = testsDataProp?.GetValue(comClash);
							var testsProp = testsData?.GetType().GetProperty("Tests", BindingFlags.Public | BindingFlags.Instance);
							var comTests = testsProp?.GetValue(testsData);
							object comTest = null;
							if (comTests is System.Collections.IEnumerable testsEnum)
							{
								foreach (var ct in testsEnum)
								{
									var guidProp = ct.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance);
									var gObj = guidProp?.GetValue(ct);
									if (gObj is Guid g && g == test.Guid) { comTest = ct; break; }
								}
							}
							if (comTest == null) { Log("COM test not found by GUID"); }
							if (comTest != null)
							{
								// Выбираем тест
								var currentTestProp = comClash.GetType().GetProperty("CurrentTest", BindingFlags.Public | BindingFlags.Instance);
								try { currentTestProp?.SetValue(comClash, comTest); } catch { }
								try
								{
									var readTest = currentTestProp?.GetValue(comClash);
									var rtGuid = readTest?.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance)?.GetValue(readTest);
									Log($"COM set CurrentTest={rtGuid}");
								}
								catch { }
								// NW2020: дать времени после установки теста
								Thread.Sleep(80);

								// COM: применяем с повторами и прокачкой диспетчера, чтобы избежать гонок обновления UI
								bool comSetOk = false;
								for (int attempt = 0; attempt < 5 && !comSetOk; attempt++)
								{
									if (issue is ClashResultGroup issueGroup)
									{
										var comGroup = FindComIssueByGuidRecursive(comTest, issueGroup.Guid);
										if (comGroup == null) { Log($"Attempt {attempt+1}: COM group not found by GUID={issueGroup.Guid}"); }
										var currentGroupProp = comClash.GetType().GetProperty("CurrentGroup", BindingFlags.Public | BindingFlags.Instance);
										try { currentGroupProp?.SetValue(comClash, comGroup); } catch { }
										// NW2020: короткая пауза
										Thread.Sleep(60);
										var currentResultProp = comClash.GetType().GetProperty("CurrentResult", BindingFlags.Public | BindingFlags.Instance);
										// Некоторые версии NW требуют также установить CurrentResult = группе
										try { currentResultProp?.SetValue(comClash, comGroup); } catch { }
										// Проверяем, что выставилась нужная группа
										var readGroup = currentGroupProp?.GetValue(comClash);
										var guidProp = readGroup?.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance);
										var gObj = guidProp?.GetValue(readGroup);
										comSetOk = (gObj is Guid g && g == issueGroup.Guid);
										Log($"Attempt {attempt+1}: set group={issueGroup.Guid}, read group={gObj}, ok={comSetOk}");
										if (!comSetOk)
										{
											// fallback: очищаем CurrentResult и пробуем ещё раз
											try { currentResultProp?.SetValue(comClash, null); } catch { }
										}
									}
									else if (issue is ClashResult issueResult)
									{
										Guid? parentGuid = (issueResult.Parent as ClashResultGroup)?.Guid;
										if (parentGuid.HasValue)
										{
											var comParentGroup = FindComIssueByGuidRecursive(comTest, parentGuid.Value);
											if (comParentGroup == null) { Log($"Attempt {attempt+1}: COM parent group not found by GUID={parentGuid}"); }
											var currentGroupProp = comClash.GetType().GetProperty("CurrentGroup", BindingFlags.Public | BindingFlags.Instance);
											try { currentGroupProp?.SetValue(comClash, comParentGroup); } catch { }
											Thread.Sleep(60);
										}
										Guid issueGuid = issueResult.Guid;
										object comIssue = FindComIssueByGuidRecursive(comTest, issueGuid);
										if (comIssue == null)
										{
											var managedPath = new System.Collections.Generic.List<int>();
											if (TryGetManagedIndexPath(test, issueResult, managedPath))
											{
												var comExact = FindComNodeByIndexPath(comTest, managedPath);
												if (comExact != null) comIssue = comExact; else Log($"Attempt {attempt+1}: COM exact by path not found [{string.Join(",", managedPath)}]");
											}
											else { Log($"Attempt {attempt+1}: Managed path not found for result"); }
										}
										if (comIssue != null)
										{
											var currentResultProp = comClash.GetType().GetProperty("CurrentResult", BindingFlags.Public | BindingFlags.Instance);
											try { currentResultProp?.SetValue(comClash, comIssue); } catch { }
											// Проверяем, что выставился нужный результат
											var readRes = currentResultProp?.GetValue(comClash);
											var guidProp = readRes?.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance);
											var gObj = guidProp?.GetValue(readRes);
											comSetOk = (gObj is Guid g && g == issueResult.Guid);
											Log($"Attempt {attempt+1}: set result={issueResult.Guid}, read result={gObj}, ok={comSetOk}");
										}
										else { Log($"Attempt {attempt+1}: COM issue not found by GUID={issueGuid}"); }
									}
									// даём UI шанс обновиться
									PumpDispatcherOnce();
									if (!comSetOk) Thread.Sleep(30);
								}
							}
						}
					}
				}
				catch { }

				// Если ни managed, ни COM явно не выбрали нужный issue, пробуем через UI Automation (сначала по пути индексов, затем GUID/имя)
				if (!managedIssueSelected)
				{
					try
					{
						var managedPath = new System.Collections.Generic.List<int>();
						if (TryGetManagedIndexPath(test, issue, managedPath))
						{
							Log($"UIA path select: [{string.Join(",", managedPath)}]");
							TryActivateViaUIAutomationByIndexPath(managedPath);
						}
						else
						{
							// Если это группа и ничего не сработало, используем rename-select-restore
							if (issue is ClashResultGroup targetGroup)
							{
								string originalName = targetGroup.DisplayName ?? string.Empty;
								string tempName = $"__SELECT__ {targetGroup.Guid}";
								if (TryRenameGroupOnce(test, targetGroup.Guid, tempName))
								{
									// небольшая пауза и выбор по точному имени
									Thread.Sleep(120);
									Log($"UIA temp-name select: {tempName}");
									TryActivateViaUIAutomation(tempName, null);
									// восстановление имени
									Thread.Sleep(120);
									TryRenameGroupOnce(test, targetGroup.Guid, originalName);
								}
								else
								{
									Log("Rename group failed; fallback to UIA guid/name");
									TryActivateViaUIAutomation(issue?.DisplayName, issue?.Guid);
								}
							}
							else
							{
								Log($"UIA guid/name select: issue={issue?.Guid} name={issue?.DisplayName}");
								TryActivateViaUIAutomation(issue?.DisplayName, issue?.Guid);
							}
						}
					}
					catch { }
				}
			}
			catch { }
		}

		private bool VerifyManagedSelection(object currentIssueCtl, Guid targetGuid, bool isGroup)
		{
			for (int attempt = 0; attempt < 6; attempt++)
			{
				try
				{
					// Небольшая пауза и прокачка UI
					PumpDispatcherOnce();
					if (attempt > 0) Thread.Sleep(50);
					// читаем текущий issue
					var getMethod = currentIssueCtl.GetType().GetMethod("GetCurrentIssueAsSavedItem", BindingFlags.Public | BindingFlags.Instance);
					var savedItem = getMethod?.Invoke(currentIssueCtl, null) as SavedItem;
					var guid = savedItem?.Guid ?? Guid.Empty;
					var ok = guid == targetGuid;
					Log($"Managed verify {attempt+1}: target={(isGroup?"Group":"Result")} {targetGuid}, read={guid}, ok={ok}");
					if (ok) return true;
					// если не совпало, повторим установку
					if (isGroup)
					{
						// Попробуем ещё раз выставить группу
						// savedItem может быть не той группой — у нас нет объекта группы здесь, поэтому повторную установку сделаем на стороне вызывающего кода
					}
					else
					{
						// Для результата перезададим текущий результат не меняя группу
						// К сожалению, без объекта результата повторно установить нельзя здесь — оставляем только ожидание.
					}
				}
				catch { }
			}
			return false;
		}

		private void PumpDispatcherOnce()
		{
			try
			{
				var frame = new DispatcherFrame();
				Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => frame.Continue = false));
				Dispatcher.PushFrame(frame);
			}
			catch { }
		}

		// Активирует вкладку Clash Detective в интерфейсе Navisworks через UI Automation
		private void TryActivateClashPanelUi()
		{
			try
			{
				var root = System.Windows.Automation.AutomationElement.RootElement;
				if (root == null) return;
				var navWindow = root.FindFirst(System.Windows.Automation.TreeScope.Children,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, _doc?.Title ?? ""));
				if (navWindow == null) return;
				// Ищем вкладку/панель по известным именам интерфейса
				string[] names = { "Clash Detective", "Проверка коллизий", "Проверка столкновений" };
				foreach (var n in names)
				{
					var tab = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
						new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, n));
					if (tab != null)
					{
						var sel = tab.GetCurrentPattern(System.Windows.Automation.SelectionItemPattern.Pattern) as System.Windows.Automation.SelectionItemPattern;
						try { sel?.Select(); Log($"Activated panel: {n}"); } catch { }
						break;
					}
				}
			}
			catch { }
		}

		private static string GetLogPath()
		{
			try { return Path.Combine(Path.GetTempPath(), "ClashSelection.log"); } catch { return "ClashSelection.log"; }
		}

		private void Log(string message)
		{
			try
			{
				File.AppendAllText(GetLogPath(), $"[{DateTime.Now:HH:mm:ss.fff}] {message}\r\n");
			}
			catch { }
		}

		private bool TryRenameGroupOnce(ClashTest test, Guid groupGuid, string newName)
		{
			try
			{
				if (test == null) return false;
				int idx = _documentClash.TestsData.Tests.IndexOf(test);
				if (idx < 0) return false;
				var copy = (ClashTest)test.CreateCopy();
				var grp = FindGroupByGuid(copy, groupGuid);
				if (grp == null) return false;
				grp.DisplayName = newName ?? string.Empty;
				_documentClash.TestsData.TestsReplaceWithCopy(idx, copy);
				PumpDispatcherOnce();
				return true;
			}
			catch { return false; }
		}

		private bool TryInvokeMethod(object target, string[] methodNames, object[] args)
		{
			foreach (var name in methodNames)
			{
				var methods = target.GetType().GetMethods(BindingFlags.Public | BindingFlags.Instance)
					.Where(m => string.Equals(m.Name, name, StringComparison.Ordinal))
					.ToList();
				foreach (var m in methods)
				{
					var pars = m.GetParameters();
					if (pars.Length != args.Length) continue;
					bool compatible = true;
					for (int i = 0; i < pars.Length; i++)
					{
						if (args[i] == null) continue;
						if (!pars[i].ParameterType.IsAssignableFrom(args[i].GetType()))
						{
							compatible = false;
							break;
						}
					}
					if (!compatible) continue;
					try { m.Invoke(target, args); return true; } catch { }
				}
			}
			return false;
		}

		private void FocusOnItems(ModelItemCollection items)
		{
			if (items == null || items.Count == 0) return;
			try
			{
				// Текущая выборка в Navisworks копируется, а не редактируется напрямую
				var selection = new ModelItemCollection();
				foreach (var it in items) selection.Add(it);
				_doc.CurrentSelection.CopyFrom(selection);
				// Попытка приблизить камеру к выделению через interop, если доступно
				TryZoomToSelectedViaInterop();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Не удалось выделить элементы: " + ex.Message);
			}
		}

		private void TryZoomToSelectedViaInterop()
		{
			// Сначала через COM — надёжно зуммирует выделение в текущем виде (без dynamic)
			try
			{
				var comState = ComApiBridge.State; // InwOpState
				var currentViewProp = comState?.GetType().GetProperty("CurrentView", BindingFlags.Public | BindingFlags.Instance);
				var comView = currentViewProp?.GetValue(comState);
				if (comView != null)
				{
					var zoomM = comView.GetType().GetMethod("ZoomSelected", BindingFlags.Public | BindingFlags.Instance)
						?? comView.GetType().GetMethod("ZoomToSelection", BindingFlags.Public | BindingFlags.Instance)
						?? comView.GetType().GetMethod("FitToSelection", BindingFlags.Public | BindingFlags.Instance);
					if (zoomM != null) { zoomM.Invoke(comView, null); return; }
				}
			}
			catch { }

			// Fallback: через managed API отражением
			try
			{
				var state = _doc?.State;
				if (state == null) return;
				var currentView = state.GetType().GetProperty("CurrentView", BindingFlags.Public | BindingFlags.Instance)?.GetValue(state);
				if (currentView == null) return;
				var m = currentView.GetType().GetMethod("ZoomSelected", BindingFlags.Public | BindingFlags.Instance)
					?? currentView.GetType().GetMethod("ZoomToSelection", BindingFlags.Public | BindingFlags.Instance)
					?? currentView.GetType().GetMethod("FitToSelection", BindingFlags.Public | BindingFlags.Instance);
				m?.Invoke(currentView, null);
			}
			catch { }
		}

		// Последняя надежда: через UI Automation ищем список Clash Detective и кликаем по строке (по GUID или имени)
		private void TryActivateViaUIAutomation(string displayName, Guid? guid)
		{
			try
			{
				if (string.IsNullOrWhiteSpace(displayName) && !guid.HasValue) return;
				var root = System.Windows.Automation.AutomationElement.RootElement;
				if (root == null) return;
				// Ищем окно Navisworks
				var navWindow = root.FindFirst(System.Windows.Automation.TreeScope.Children,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, _doc?.Title ?? ""));
				if (navWindow == null) return;
				// Сначала пробуем найти по GUID (в имени/AutomationId)
				System.Windows.Automation.AutomationElement match = null;
				if (guid.HasValue)
				{
					string guidStr = guid.Value.ToString();
					match = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
						new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, guidStr));
					if (match == null)
					{
						match = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
							new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.AutomationIdProperty, guidStr));
					}
				}
				// Затем по имени
				if (match == null && !string.IsNullOrWhiteSpace(displayName))
				{
					match = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
						new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, displayName));
				}
				if (match == null) return;
				var invoke = match.GetCurrentPattern(System.Windows.Automation.InvokePattern.Pattern) as System.Windows.Automation.InvokePattern;
				if (invoke != null)
				{
					invoke.Invoke();
					return;
				}
				// Если нет Invoke, пробуем выбрать
				var selection = match.GetCurrentPattern(System.Windows.Automation.SelectionItemPattern.Pattern) as System.Windows.Automation.SelectionItemPattern;
				selection?.Select();
			}
			catch { }
		}

		// Доп. вариант: выбор по GUID через UI Automation, если имя не уникально/не сработало
		private void TryActivateViaUIAutomationByGuid(Guid guid)
		{
			try
			{
				if (guid == Guid.Empty) return;
				var root = System.Windows.Automation.AutomationElement.RootElement;
				if (root == null) return;
				var navWindow = root.FindFirst(System.Windows.Automation.TreeScope.Children,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, _doc?.Title ?? ""));
				if (navWindow == null) return;
				var match = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, guid.ToString()));
				if (match == null) return;
				var selection = match.GetCurrentPattern(System.Windows.Automation.SelectionItemPattern.Pattern) as System.Windows.Automation.SelectionItemPattern;
				selection?.Select();
			}
			catch { }
		}

		private Guid GetIssueGuidForActivation(SavedItem issue)
		{
			// Возвращаем GUID самого выбранного элемента (группа или результат)
			// Не подменяем на первый результат группы, чтобы не было смещения выбора
			return issue.Guid;
		}

		private IEnumerable<object> EnumerateComCollection(object comCollection)
		{
			if (comCollection == null) yield break;
			if (comCollection is System.Collections.IEnumerable enumerable)
			{
				foreach (var item in enumerable) yield return item;
				yield break;
			}
			var countProp = comCollection.GetType().GetProperty("Count", BindingFlags.Public | BindingFlags.Instance);
			var itemMethod = comCollection.GetType().GetMethod("Item", BindingFlags.Public | BindingFlags.Instance, null, new[] { typeof(int) }, null);
			int count = 0;
			try { count = (int)(countProp?.GetValue(comCollection) ?? 0); } catch { }
			for (int i = 1; i <= count; i++)
			{
				object val = null;
				try { val = itemMethod?.Invoke(comCollection, new object[] { i }); } catch { }
				if (val != null) yield return val;
			}
		}

		private object FindComIssueByGuidRecursive(object comNode, Guid targetGuid)
		{
			if (comNode == null) return null;
			var guidProp = comNode.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance);
			var gObj = guidProp?.GetValue(comNode);
			if (gObj is Guid g && g == targetGuid) return comNode;
			var childrenProp = comNode.GetType().GetProperty("Children", BindingFlags.Public | BindingFlags.Instance);
			var children = childrenProp?.GetValue(comNode);
			foreach (var child in EnumerateComCollection(children))
			{
				var found = FindComIssueByGuidRecursive(child, targetGuid);
				if (found != null) return found;
			}
			return null;
		}

		// Построение пути индексов до issue в дереве managed (по свойству Children) через отражение,
		// чтобы одинаково работать для ClashTest и ClashResultGroup и избежать конфликтов типов GroupItem
		private bool TryGetManagedIndexPath(object root, SavedItem target, System.Collections.Generic.List<int> path)
		{
			if (root == null || target == null) return false;
			var childrenProp = root.GetType().GetProperty("Children", BindingFlags.Public | BindingFlags.Instance);
			var childrenObj = childrenProp?.GetValue(root);
			if (childrenObj == null) return false;
			// Пытаемся получить Count и индексированный доступ [i]
			var countProp = childrenObj.GetType().GetProperty("Count", BindingFlags.Public | BindingFlags.Instance);
			int count = 0;
			try { count = (int)(countProp?.GetValue(childrenObj) ?? 0); } catch { }
			for (int i = 0; i < count; i++)
			{
				object child = null;
				try { child = childrenObj.GetType().GetProperty("Item")?.GetValue(childrenObj, new object[] { i }); } catch { }
				if (child == null)
				{
					// альтернативный способ – если Children реализует IEnumerable
					int idx = 0;
					foreach (var c in (System.Collections.IEnumerable)childrenObj)
					{
						if (idx == i) { child = c; break; }
						idx++;
					}
				}
				if (child == null) continue;
				var guidProp = child.GetType().GetProperty("Guid", BindingFlags.Public | BindingFlags.Instance);
				var gObj = guidProp?.GetValue(child);
				if (gObj is Guid g && g == target.Guid)
				{
					path.Add(i);
					return true;
				}
				// рекурсивно спускаемся, если у child есть Children
				var childChildrenProp = child.GetType().GetProperty("Children", BindingFlags.Public | BindingFlags.Instance);
				if (childChildrenProp != null)
				{
					path.Add(i);
					if (TryGetManagedIndexPath(child, target, path)) return true;
					path.RemoveAt(path.Count - 1);
				}
			}
			return false;
		}

		private object FindComNodeByIndexPath(object comRoot, System.Collections.Generic.IReadOnlyList<int> path)
		{
			object current = comRoot;
			for (int depth = 0; depth < path.Count; depth++)
			{
				var childrenProp = current.GetType().GetProperty("Children", BindingFlags.Public | BindingFlags.Instance);
				var children = childrenProp?.GetValue(current);
				if (children == null) return null;
				int targetIndex = path[depth]; // 0-based
				int idx = 0;
				object next = null;
				foreach (var c in EnumerateComCollection(children))
				{
					if (idx == targetIndex) { next = c; break; }
					idx++;
				}
				if (next == null) return null;
				current = next;
			}
			return current;
		}

		// UIA: выбор элемента Clash Detective по пути индексов (соответствует Children managed-дерева)
		private void TryActivateViaUIAutomationByIndexPath(System.Collections.Generic.IReadOnlyList<int> indexPath)
		{
			try
			{
				if (indexPath == null || indexPath.Count == 0) return;
				var root = System.Windows.Automation.AutomationElement.RootElement;
				if (root == null) return;
				var navWindow = root.FindFirst(System.Windows.Automation.TreeScope.Children,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.NameProperty, _doc?.Title ?? ""));
				if (navWindow == null) return;
				// Ищем дерево результатов Clash Detective (обычно ControlType.Tree или List)
				var tree = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
					new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.ControlTypeProperty, System.Windows.Automation.ControlType.Tree));
				if (tree == null)
				{
					tree = navWindow.FindFirst(System.Windows.Automation.TreeScope.Descendants,
						new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.ControlTypeProperty, System.Windows.Automation.ControlType.List));
					if (tree == null) return;
				}
				var current = tree;
				for (int depth = 0; depth < indexPath.Count; depth++)
				{
					int targetIndex = indexPath[depth];
					var children = current.FindAll(System.Windows.Automation.TreeScope.Children,
						new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.ControlTypeProperty, System.Windows.Automation.ControlType.TreeItem));
					if (children == null || children.Count == 0)
					{
						children = current.FindAll(System.Windows.Automation.TreeScope.Children,
							new System.Windows.Automation.PropertyCondition(System.Windows.Automation.AutomationElement.ControlTypeProperty, System.Windows.Automation.ControlType.ListItem));
					}
					if (children == null || children.Count <= targetIndex) return;
					current = children[targetIndex];
					// разворачиваем, если есть ExpandCollapse
					var ec = current.GetCurrentPattern(System.Windows.Automation.ExpandCollapsePattern.Pattern) as System.Windows.Automation.ExpandCollapsePattern;
					try { if (ec != null && ec.Current.ExpandCollapseState != System.Windows.Automation.ExpandCollapseState.Expanded) ec.Expand(); } catch { }
				}
				var sel = current.GetCurrentPattern(System.Windows.Automation.SelectionItemPattern.Pattern) as System.Windows.Automation.SelectionItemPattern;
				try { sel?.Select(); } catch { }
			}
			catch { }
		}

		private System.Collections.Generic.IEnumerable<ResultRow> EnumerateResultsWithGroupFromTest(ClashTest test)
		{
			foreach (var r in test.Children.OfType<ClashResult>())
				yield return new ResultRow { Result = r, GroupName = null, ParentGroup = null };

			foreach (var g in test.Children.OfType<ClashResultGroup>())
			{
				foreach (var row in EnumerateResultsWithGroupFromGroup(g))
					yield return row;
			}
		}

		private System.Collections.Generic.IEnumerable<ResultRow> EnumerateResultsWithGroupFromGroup(ClashResultGroup group)
		{
			foreach (var r in group.Children.OfType<ClashResult>())
				yield return new ResultRow { Result = r, GroupName = group.DisplayName, ParentGroup = group };

			foreach (var g in group.Children.OfType<ClashResultGroup>())
			{
				foreach (var row in EnumerateResultsWithGroupFromGroup(g))
					yield return row;
			}
		}

		private System.Collections.Generic.IEnumerable<ClashResult> GetAllResultsFromTest(ClashTest test)
		{
			foreach (var r in test.Children.OfType<ClashResult>())
				yield return r;

			foreach (var g in test.Children.OfType<ClashResultGroup>())
			{
				foreach (var r in GetAllResultsFromGroup(g))
					yield return r;
			}
		}

		private System.Collections.Generic.IEnumerable<ClashResult> GetAllResultsFromGroup(ClashResultGroup group)
		{
			foreach (var r in group.Children.OfType<ClashResult>())
				yield return r;

			foreach (var g in group.Children.OfType<ClashResultGroup>())
			{
				foreach (var r in GetAllResultsFromGroup(g))
					yield return r;
			}
		}

		private ClashResult FindResultByGuid(ClashTest test, Guid guid)
		{
			foreach (var r in test.Children.OfType<ClashResult>())
				if (r.Guid == guid) return r;

			foreach (var g in test.Children.OfType<ClashResultGroup>())
			{
				var found = FindResultByGuid(g, guid);
				if (found != null) return found;
			}
			return null;
		}

		private ClashResult FindResultByGuid(ClashResultGroup group, Guid guid)
		{
			foreach (var r in group.Children.OfType<ClashResult>())
				if (r.Guid == guid) return r;

			foreach (var g in group.Children.OfType<ClashResultGroup>())
			{
				var found = FindResultByGuid(g, guid);
				if (found != null) return found;
			}
			return null;
		}

		private ClashResultGroup FindGroupByGuid(ClashTest test, Guid guid)
		{
			foreach (var g in test.Children.OfType<ClashResultGroup>())
			{
				if (g.Guid == guid) return g;
				var found = FindGroupByGuid(g, guid);
				if (found != null) return found;
			}
			return null;
		}

		private ClashResultGroup FindGroupByGuid(ClashResultGroup group, Guid guid)
		{
			foreach (var g in group.Children.OfType<ClashResultGroup>())
			{
				if (g.Guid == guid) return g;
				var found = FindGroupByGuid(g, guid);
				if (found != null) return found;
			}
			return null;
		}

		private void ApplyRenameButton_Click(object sender, RoutedEventArgs e)
		{
			var findText = FindBox.Text ?? string.Empty;
			var replaceText = ReplaceBox.Text ?? string.Empty;

			try
			{
				bool hasCheckedTests = _checkedTestIds.Count > 0;
				bool hasCheckedRows = _checkedRowIds.Count > 0;

				// Запрещаем одновременное переименование тестов и коллизий/групп
				if (hasCheckedTests && hasCheckedRows)
				{
					MessageBox.Show("Выберите только тесты или только коллизии/группы для переименования.");
					return;
				}

				// 1) Только тесты
				if (hasCheckedTests)
				{
					int testsRenamed = 0;
					var allTests = _documentClash?.TestsData?.Tests?.OfType<ClashTest>()?.ToList() ?? new System.Collections.Generic.List<ClashTest>();
					foreach (var test in allTests)
					{
						if (!_checkedTestIds.Contains(test.Guid)) continue;
						int idx = _documentClash.TestsData.Tests.IndexOf(test);
						if (idx < 0) continue;
						var copy = (ClashTest)test.CreateCopy();
						var originalName = copy.DisplayName ?? string.Empty;
						var newName = string.IsNullOrWhiteSpace(findText) ? (replaceText ?? string.Empty) : originalName.Replace(findText, replaceText);
						if (newName != originalName)
						{
							copy.DisplayName = newName;
							_documentClash.TestsData.TestsReplaceWithCopy(idx, copy);
							testsRenamed++;
						}
					}
					LoadTests();
					_checkedTestIds.Clear();
					MessageBox.Show(testsRenamed > 0 ? "Тесты успешно переименованы." : "Нет изменений по заданным критериям.");
					return;
				}

				// 2) Только коллизии/группы
				if (hasCheckedRows)
				{
					int changes = 0;
					var allTests = _documentClash?.TestsData?.Tests?.OfType<ClashTest>()?.ToList() ?? new System.Collections.Generic.List<ClashTest>();
					for (int ti = 0; ti < allTests.Count; ti++)
					{
						var test = allTests[ti];
						var copy = (ClashTest)test.CreateCopy();
						bool testChanged = false;

             foreach (var rowId in _checkedRowIds.ToList())
                {
                    var group = FindGroupByGuid(copy, rowId);
                    if (group != null)
                    {
                        var originalName = group.DisplayName ?? string.Empty;
                        var newName = string.IsNullOrWhiteSpace(findText) ? (replaceText ?? string.Empty) : originalName.Replace(findText, replaceText);
                        if (newName != originalName)
                        {
                            group.DisplayName = newName;
                            changes++;
                            testChanged = true;
                        }
                        continue;
                    }
                    var clash = FindResultByGuid(copy, rowId);
                    if (clash != null)
                    {
                        var originalName = clash.DisplayName ?? string.Empty;
                        var newName = string.IsNullOrWhiteSpace(findText) ? (replaceText ?? string.Empty) : originalName.Replace(findText, replaceText);
                        if (newName != originalName)
                        {
                            clash.DisplayName = newName;
                            changes++;
                            testChanged = true;
                        }
                    }
                }
                if (testChanged)
                {
                    int idx = _documentClash.TestsData.Tests.IndexOf(test);
                    if (idx >= 0)
                    {
                        _documentClash.TestsData.TestsReplaceWithCopy(idx, copy);
                    }
                }
            }
            LoadTests();
            _checkedRowIds.Clear();
            MessageBox.Show(changes > 0 ? "Коллизии/группы успешно переименованы." : "Нет изменений по заданным критериям.");
            return;
        }

        // 3) Если ничего не выбрано
        MessageBox.Show("Выберите тесты или коллизии/группы для переименования через чекбоксы.");
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Ошибка при переименовании: {ex.Message}\n{ex.StackTrace}");
    }
}
	}
}
